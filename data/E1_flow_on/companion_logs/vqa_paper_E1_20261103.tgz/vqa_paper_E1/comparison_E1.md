# VQA-EKF comparison — experiment E1

Generated 2026-11-03 17:31. Valid sorties only.

| Metric (median [IQR]) | Arm A (constant 0.20 m) | Arm A' (tuned constant) | Arm B (VQA-EKF adaptive) |
|---|---|---|---|
| Sorties flown/completed/valid/truth | 15 / 15 / 15 / 15 | 15 / 15 / 15 / 15 | 15 / 15 / 15 / 15 |
| Touchdown CEP50 (cm)  ← primary | 13.7 | 13.7 | 12.5 |
| Touchdown CEP95 (cm) | 16.8 | 15.9 | 18.4 |
| Touchdown mean ± SD (cm) | 13.2 ± 2.6 | 13.3 ± 2.1 | 13.5 ± 3.2 |
| Overshoot after last step (cm) | 6.0 [4.3–8.7] | 4.4 [3.4–4.6] | 4.0 [3.5–5.6] |
| Settling time to 5 cm (s) | — | — | — |
| Hold RMS in CONVERGE (cm) | 11.4 [11.2–11.7] | 11.4 [11.2–11.4] | 11.4 [11.2–11.6] |
| σ sent in maneuver (cm) | 20.00 [20.00–20.00] | 1.14 [1.14–1.14] | 1.07 [1.06–1.09] |
| Max tilt in maneuver (deg) | 18.6 [18.5–18.8] | 19.2 [19.1–19.4] | 19.1 [19.0–19.4] |
| Frames accepted in maneuver (%) | 94.8 [88.3–96.2] | 92.9 [83.8–94.2] | 93.3 [80.9–94.8] |
| Latency capture→send (ms) | 51.6 [51.3–52.2] | 52.1 [51.7–52.5] | 52.0 [51.9–52.3] |
| Battery at takeoff (V) | 15.57 [15.35–15.95] | 15.69 [15.43–15.96] | 16.09 [15.45–16.32] |

| Comparison | Metric | Median diff | 95% CI | Cliff's δ | p | n (B/ref) |
|---|---|---|---|---|---|---|
| B vs A | Touchdown radial (cm) | -1.12 | [-2.70, +3.50] | +0.02 | 0.950 | 15/15 |
| B vs A | Overshoot (cm) | -2.08 | [-4.88, +0.63] | -0.37 | 0.089 | 15/15 |
| B vs A | Hold RMS (cm) | -0.04 | [-0.38, +0.23] | -0.14 | 0.520 | 15/15 |
| B vs A' | Touchdown radial (cm) | -1.11 | [-2.04, +2.96] | +0.02 | 0.934 | 15/15 |
| B vs A' | Overshoot (cm) | -0.42 | [-0.98, +1.49] | +0.04 | 0.868 | 15/15 |
| B vs A' | Hold RMS (cm) | +0.01 | [-0.17, +0.26] | +0.10 | 0.648 | 15/15 |
