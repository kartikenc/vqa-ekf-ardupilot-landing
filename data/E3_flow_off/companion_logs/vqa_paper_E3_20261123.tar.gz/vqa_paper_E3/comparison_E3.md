# VQA-EKF comparison — experiment E3

Generated 2026-11-23 13:24. Valid sorties only.

| Metric (median [IQR]) | Arm A (constant 0.20 m) | Arm A' (tuned constant) | Arm B (VQA-EKF adaptive) |
|---|---|---|---|
| Sorties flown/completed/valid/truth | 15 / 15 / 15 / 15 | 17 / 15 / 15 / 15 | 16 / 15 / 15 / 15 |
| Touchdown CEP50 (cm)  ← primary | 13.5 | 13.5 | 11.8 |
| Touchdown CEP95 (cm) | 18.8 | 18.2 | 15.0 |
| Touchdown mean ± SD (cm) | 13.8 ± 3.4 | 13.8 ± 2.7 | 11.7 ± 2.4 |
| Overshoot after last step (cm) | 4.0 [3.3–6.8] | 3.6 [2.5–5.9] | 3.9 [2.9–4.7] |
| Settling time to 5 cm (s) | — | — | — |
| Hold RMS in CONVERGE (cm) | 11.6 [11.3–11.7] | 11.4 [11.2–11.6] | 11.3 [11.2–11.5] |
| σ sent in maneuver (cm) | 20.00 [20.00–20.00] | 1.14 [1.14–1.14] | 1.14 [1.12–1.15] |
| Max tilt in maneuver (deg) | 18.7 [18.6–18.9] | 18.9 [18.9–19.2] | 18.9 [18.6–19.0] |
| Frames accepted in maneuver (%) | 97.4 [96.9–97.7] | 96.0 [92.7–96.3] | 96.1 [94.2–96.2] |
| Latency capture→send (ms) | 52.1 [52.0–53.1] | 52.2 [51.9–52.8] | 52.3 [52.0–52.4] |
| Battery at takeoff (V) | 15.92 [15.59–16.18] | 15.60 [15.44–16.25] | 16.22 [15.64–16.29] |

| Comparison | Metric | Median diff | 95% CI | Cliff's δ | p | n (B/ref) |
|---|---|---|---|---|---|---|
| B vs A | Touchdown radial (cm) | -1.69 | [-5.03, +0.85] | -0.33 | 0.130 | 15/15 |
| B vs A | Overshoot (cm) | -0.08 | [-2.75, +0.74] | -0.18 | 0.407 | 15/15 |
| B vs A | Hold RMS (cm) | -0.33 | [-0.43, +0.07] | -0.34 | 0.115 | 15/15 |
| B vs A' | Touchdown radial (cm) | -1.77 | [-4.56, +0.76] | -0.44 | 0.044 | 15/15 |
| B vs A' | Overshoot (cm) | +0.29 | [-2.17, +1.62] | -0.03 | 0.901 | 15/15 |
| B vs A' | Hold RMS (cm) | -0.10 | [-0.35, +0.28] | -0.03 | 0.901 | 15/15 |
